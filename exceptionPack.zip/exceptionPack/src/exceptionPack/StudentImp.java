package exceptionPack;

public class StudentImp implements StudentInterface
{
	String id,name;
	public void addStudent()
	{
		id="S23445";
		name="neha";
	}
	public void printStudent()
	{
		System.out.println("student id="+id);
		System.out.println("student name="+name);
	}
	public static void main(String[] args) 
	{
		
		StudentImp stu = new StudentImp();//object created  by only using student implementation class
		stu.addStudent();
		stu.printStudent();
		
		StudentInterface sin = new StudentImp();//object created by referencing student implementation class
		sin.addStudent();
		sin.printStudent();
		

	}

}
