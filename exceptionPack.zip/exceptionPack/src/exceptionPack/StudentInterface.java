package exceptionPack;

public interface StudentInterface {
	public void addStudent();
	public void printStudent();
}

