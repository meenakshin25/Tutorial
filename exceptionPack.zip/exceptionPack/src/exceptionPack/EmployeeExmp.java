package exceptionPack;

public class EmployeeExmp {
	int id;
	String name;
	public static void main(String[] args) 
	{
		EmployeeExmp employee= new EmployeeExmp();
		employee.accept();
	}
	void accept()
	{
		int ar[]=new int[10];
		ar[0]=20;
		ar[1]=25;
		try
		{
		System.out.println(ar[14]);
		}
		catch(Exception e)
		{
			System.out.println("exception handled....");
		}
		finally 
		{
			int a,b;
			a=15;
			b=20;
			b+=50;
			a-=80;
			System.out.println(a);
			System.out.println(b);
		}
	}
	
}
