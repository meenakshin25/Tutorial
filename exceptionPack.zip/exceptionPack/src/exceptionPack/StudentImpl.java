package exceptionPack;

public class StudentImpl extends StudentExmp 
{
	String id,name;
	public void addStudent()
	{
		id="S1711";
		name="pooja";
	}
	public void printStudent()
	{
		System.out.println("student id="+id);
		System.out.println("student name="+name);
	}
	public static void main(String[] args) 
	{
		StudentImpl st = new StudentImpl();//object created  by only using student implementation class
		st.addStudent();
		st.printStudent();
		
		StudentExmp s = new StudentImpl();//object created by referencing student implementation class
		s.addStudent();
		s.printStudent();
		s.Calculate();
	}

}
