package exceptionPack;

class Manager
{
	int mId;
	String mName;
	void addManager()
	{
		mId=201;
		mName="rahul";
	}
	void displayManager()
	{
		System.out.println("manager id="+mId);
		System.out.println("manager name="+mName);
	}
}
class Clerk extends Manager
{
	int cId;
	String cName;
	void addClerk()
	{
		cId=201;
		cName="arun";
	}
	void displayClerk()
	{
		System.out.println("clerk id="+cId);
		System.out.println("clerk name="+cName);
	}
	@Override
	void addManager()
	{
		for(int i=65;i<=80;i++)
		{
			System.out.println((char)i);
		}
	}
}

public class ExampleClass {

	public static void main(String[] args) {
		Clerk c = new Clerk();
		c.addClerk();
		c.displayClerk();
		c.addManager();
		c.displayManager();
		System.out.println(c.toString());
		}

}

